<?php

/*
 *
 *  ____            _        _   __  __ _                  __  __ ____
 * |  _ \ ___   ___| | _____| |_|  \/  (_)_ __   ___      |  \/  |  _ \
 * | |_) / _ \ / __| |/ / _ \ __| |\/| | | '_ \ / _ \_____| |\/| | |_) |
 * |  __/ (_) | (__|   <  __/ |_| |  | | | | | |  __/_____| |  | |  __/
 * |_|   \___/ \___|_|\_\___|\__|_|  |_|_|_| |_|\___|     |_|  |_|_|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author PocketMine Team
 * @link http://www.pocketmine.net/
 *
 *
*/

declare(strict_types=1);

namespace pocketmine\network\mcpe\protocol;

use pocketmine\utils\Binary;

use pocketmine\network\mcpe\NetworkSession;

class SubClientLoginPacket extends DataPacket{
	public const NETWORK_ID = ProtocolInfo331::SUB_CLIENT_LOGIN_PACKET;
	public const PACKET_NAME = "SUB_CLIENT_LOGIN_PACKET";

	/** @var string */
	public $connectionRequestData;

	protected function decodePayload(){
		$this->connectionRequestData = $this->getString();
	}

	protected function encodePayload(){
		$this->putString($this->connectionRequestData);
	}

	public function handle(NetworkSession $session) : bool{
		return $session->handleSubClientLogin($this);
	}
}
